/*
 * https://www.youtube.com/watch?v=u_Ck9j-_4-o 
 * Link above to what the original game looks like
 */
package videogameexam1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import sun.audio.AudioData;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
import sun.audio.ContinuousAudioDataStream;

public class VideoGameExam1 extends Application {

    public String character;
    public static String difficulty;
    public static double spriteSpeed;
    public boolean gameStart = false; //Used to turn off the character selection and start the game

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {

        music(); //Plays the background music
        

        Timeline timeline = new Timeline( //Loops the music after it stops playing
                new KeyFrame(Duration.seconds(52), e -> {
                    music();
                })
        );
        timeline.play();

        stage.setTitle("Target Practice");
        character = "Link"; //Set link as the default character to avoid a null pointer exception
        difficulty = "Easy"; //Set easy as the default to avoid a null pointer exception
        spriteSpeed = .5;
        runCharacterSelectionScreen(stage);
        stage.show();
    }

    //blocker is 15 x 16
    //arrow is 7 x 15
    //target is 16 by 16
    private boolean checkCollision(Sprite s1, Sprite arrow) {
        if (s1.getTranslateX() < arrow.getTranslateX() + 7
                && s1.getTranslateX() + 15 > arrow.getTranslateX()
                && s1.getTranslateY() < arrow.getTranslateY() + 15
                && s1.getTranslateY() + 16 > arrow.getTranslateY()) {
            return true;
        } else {
            return false;
        }

    }

    public void runCharacterSelectionScreen(Stage primaryStage) {
        Group root = new Group();
        Scene scene = new Scene(root, 256, 223); //Originally were 320, 420 //Background Image is 256 x 223 so we will use that instead

        ImageView background = new ImageView(new Image("resources/Black.png"));
        root.getChildren().add(background);

        ImageView select = new ImageView(new Image("resources/Select.png"));
        select.setTranslateY(60);
        root.getChildren().add(select);

        ImageView link = new ImageView(new Image("resources/Link/LinkStand.png"));
        ImageView pika = new ImageView(new Image("resources/Pika/PikaStand.png"));
        ImageView gab = new ImageView(new Image("resources/Gab/GabStand.png"));

        link.setTranslateX(60);
        pika.setTranslateX(112);
        gab.setTranslateX(160);

        link.setTranslateY(70);
        pika.setTranslateY(70);
        gab.setTranslateY(67);

        root.getChildren().add(link); //How to add
        root.getChildren().add(pika); //How to add
        root.getChildren().add(gab); //How to add

        link.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent t) {
                character = "Link";

            }
        });

        pika.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent t) {
                character = "Pika";

            }
        });

        gab.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent t) {
                character = "Gab";

            }
        });

        //Scene 1
        Label label1 = new Label("Select a character and difficulty");
        Label label2 = new Label("then press the Start button");
        label1.setTranslateX(40);
        label2.setTranslateX(45);
        label1.setTranslateY(10);
        label2.setTranslateY(25);
        label1.setTextFill(Color.web("#FFFFFF"));
        label2.setTextFill(Color.web("#FFFFFF"));
        root.getChildren().add(label1); //How to add
        root.getChildren().add(label2); //How to add

        ToggleButton tb1 = new ToggleButton("Easy");
        tb1.setTranslateX(40);
        tb1.setTranslateY(130);
        ToggleButton tb2 = new ToggleButton("Medium");
        tb2.setTranslateX(85);
        tb2.setTranslateY(130);
        ToggleButton tb3 = new ToggleButton("Hard");
        tb3.setTranslateX(150);
        tb3.setTranslateY(130);
        ToggleGroup group = new ToggleGroup();
        tb1.setToggleGroup(group);
        tb2.setToggleGroup(group);
        tb3.setToggleGroup(group);
        root.getChildren().add(tb1);
        root.getChildren().add(tb2);
        root.getChildren().add(tb3);

        Button button1 = new Button("Start");
        button1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (tb1.isSelected()) {
                    difficulty = "Easy";
                    spriteSpeed = .5;
                } else if (tb2.isSelected()) {
                    difficulty = "Medium";
                    spriteSpeed = 1;
                } else if (tb3.isSelected()) {
                    difficulty = "Hard";
                    spriteSpeed = 2;
                }

                primaryStage.setScene(getShootingScene(primaryStage));
            }
        });

        button1.setLayoutX(100);
        button1.setLayoutY(175);

        root.getChildren().add(button1); //How to add
        //Set the character

        //Set the difficulty
        AnimationTimer animation = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (character.equals("Link")) {
                    select.setTranslateX(47);
                } else if (character.equals("Pika")) {
                    select.setTranslateX(102);
                } else if (character.equals("Gab")) {
                    select.setTranslateX(155);
                }

            }
        };
        animation.start();

        primaryStage.setScene(scene);
    }

    public Scene getShootingScene(Stage myStage) {

        Group root = new Group();
        Scene scene = new Scene(root, 256, 223); //Originally were 320, 420 //Background Image is 256 x 223 so we will use that instead

        //Set up the backdrop
        //ImageView background = new ImageView(new Image(getClass().getResource("resources/Background.png").toURI().toString()));//getClass().getResource("resources/Background.png").toURI().toString()
        ImageView background = new ImageView(new Image("resources/Background.png"));
        root.getChildren().add(background);

        //Blockers
        Blocker[] blockers = new Blocker[4];
        for (int i = 0; i < 4; i++) {
            blockers[i] = new Blocker(i, spriteSpeed);
            root.getChildren().add(blockers[i]);
        }

        //Targets
        ArrayList<Target> targets = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            targets.add(new Target(i, spriteSpeed));
            root.getChildren().add(targets.get(i));
        }

        Arrow myArrow = new Arrow(difficulty);
        root.getChildren().add(myArrow);

        Player link = new Player(scene, myArrow, character);
        root.getChildren().add(link);

        //Show Arrows Left
        Label label1 = new Label("Arrows Left: " + myArrow.getAmount());
        label1.setTranslateX(30);
        label1.setTextFill(Color.web("#FFFFFF"));
        root.getChildren().add(label1); //How to add

        //Set up sprites
        AnimationTimer animation = new AnimationTimer() {
            @Override
            public void handle(long now) {
                //Move sprites
                for (int i = 0; i < blockers.length; i++) {
                    blockers[i].update();
                    if (checkCollision(blockers[i], myArrow)) {
                        myArrow.setTranslateY(-10);
                    }
                }

                for (int j = 0; j < targets.size(); j++) {
                    targets.get(j).update();
                    if (checkCollision(targets.get(j), myArrow)) {
                        root.getChildren().remove(targets.get(j));
                        targets.remove(j);
                        if (targets.size() == 0) {
                            runWinScreen(myStage);
                        }
                        myArrow.setTranslateY(-10);
                    }
                }

                link.update();
                myArrow.update();
                label1.setText("Arrows Left: " + myArrow.getAmount());
                if (myArrow.getAmount() < 0) { //Ran out of arrows game must end
                    if (targets.size() == 0) {
                        runWinScreen(myStage);
                    } else if (targets.size() > 0) {
                        runLoseScreen(myStage);
                    }

                    myArrow.setAmount(99);
                }
                //label1 = new Label("Arrows Left: " + myArrow.getAmount()); //update arrow amount
                //Check for and handle collisions
            }
        };
        animation.start();

        ImageView leftDoor = new ImageView(new Image("resources/LeftDoor.png")); //Needed so that the sprites dont walk over the door and go under instead
        root.getChildren().add(leftDoor);

        ImageView rightDoor = new ImageView(new Image("resources/RightDoor.png")); //Needed so that the sprites dont walk over the door and go under instead
        rightDoor.setTranslateX(233);
        root.getChildren().add(rightDoor);

        return scene;

    }

    public void runLoseScreen(Stage primaryStage) {
        Group root = new Group();
        Scene scene = new Scene(root, 256, 223); //Originally were 320, 420 //Background Image is 256 x 223 so we will use that instead

        ImageView background = new ImageView(new Image("resources/Black.png"));
        root.getChildren().add(background);

        //Scene 1
        Label label1 = new Label("You lost :(");
        label1.setTranslateX(100);
        label1.setTranslateY(80);
        label1.setTextFill(Color.web("#FFFFFF"));

        root.getChildren().add(label1); //How to add

        Label label2 = new Label("It's okay though press try again!");
        label2.setTranslateX(30);
        label2.setTranslateY(100);
        label2.setTextFill(Color.web("#FFFFFF"));

        root.getChildren().add(label2); //How to add

        Button button1 = new Button("Try Again");
        button1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                runCharacterSelectionScreen(primaryStage);
            }
        });
        button1.setLayoutX(90);
        button1.setLayoutY(175);
        root.getChildren().add(button1);

        /*
        Button button1 = new Button("Try Again");
        button1.setOnAction(e -> System.out.println("HERE"));
        button1.setLayoutX(90);
        button1.setLayoutY(175);
        root.getChildren().add(button1);
        
        runCharacterSelectionScreen(primaryStage)
         */
        primaryStage.setScene(scene);

    }

    public void runWinScreen(Stage primaryStage) {

        Group root = new Group();
        Scene scene = new Scene(root, 256, 223); //Originally were 320, 420 //Background Image is 256 x 223 so we will use that instead

        ImageView background = new ImageView(new Image("resources/Black.png"));
        root.getChildren().add(background);

        ImageView winDance = new ImageView(new Image("resources/" + character + "/" + character + "Win.gif"));
        winDance.setTranslateX(90);
        winDance.setTranslateY(70);
        root.getChildren().add(winDance);

        //Scene 1
        Label label1 = new Label("You Won " + difficulty + "!");
        label1.setTranslateX(130);

        label1.setTranslateY(80);

        label1.setTextFill(Color.web("#FFFFFF"));

        root.getChildren().add(label1); //How to add

        Button button1 = new Button("Play Again");
        button1.setOnAction(e -> runCharacterSelectionScreen(primaryStage));

        button1.setLayoutX(90);
        button1.setLayoutY(175);
        root.getChildren().add(button1);

        primaryStage.setScene(scene);

    }

    public static void music() {
        AudioPlayer MGP = AudioPlayer.player;
        AudioStream BGM;
        AudioData MD;

        ContinuousAudioDataStream loop = null;

        try {
            InputStream test = new FileInputStream("src/resources/Music/Music.wav"); //C:\\Music1.wmv");
            BGM = new AudioStream(test);
            AudioPlayer.player.start(BGM);

            //MD = BGM.getData();
            //loop = new ContinuousAudioDataStream(MD);
        } catch (FileNotFoundException e) {
            System.out.print(e.toString());
        } catch (IOException error) {
            System.out.print(error.toString());
        }

        MGP.start(loop);

    }

    public static void playSound(String fileName) {
        Media m = new Media("file:///" + System.getProperty("user.dir").replace('\\', '/') + "/" + fileName);
        MediaPlayer player = new MediaPlayer(m);
        player.play();
    }

}
