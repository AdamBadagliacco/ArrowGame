/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videogameexam1;
import javafx.geometry.Bounds;
import javafx.geometry.Point2D;
import javafx.geometry.Point3D;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Sprite extends ImageView
{
    //private final Node node;
    /*
    public Sprite(Node node, Image image)
    {
        super(image);
       // this.node = node;
        
    }
*/
    public Sprite(ImageView myView){
        super(myView.getImage());
       // this.node = myView;
    }
    
    
    public void update(double dt)
    {
    }

}
