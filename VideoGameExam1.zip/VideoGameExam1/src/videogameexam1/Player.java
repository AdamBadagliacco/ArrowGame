/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videogameexam1;

import java.util.HashMap;
import java.util.Map;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

/**
 *
 * @author Alfster
 */
public class Player extends Sprite{

    private VelocityComponent vc;
    
    private static Image walkingRight;
    private static Image walkingLeft;
    private static Image walkingUp;
    private static Image walkingDown;
    
    private static Image standing;
    
    private static Image fire;

    public Player(Scene scene, Arrow myArrow, String character) {
        super(new ImageView(standing));
        vc = new VelocityComponent(this, 0, 0);
        this.setTranslateX(100);
        this.setTranslateY(150); //80 is the exact front at the green line
        
        walkingRight = new Image("resources/" + character + "/" + character + "WalkRight.gif");
    walkingLeft = new Image("resources/" + character + "/" + character + "WalkLeft.gif");
    walkingUp = new Image("resources/" + character + "/" + character + "sBack.gif");
    walkingDown = new Image("resources/" + character + "/" + character + "Forward.gif");
    
    standing = new Image("resources/" + character + "/" + character + "Stand.png");
    
    fire = new Image("resources/" + character + "/" + character + "Fire.png");
        
    setImage(standing);

        //Create the Command objects
        Command moveUp = new Command() {
            public void execute() {
                vc.setVelocityY(-1);
                vc.setVelocityX(0);
                
                setImage(walkingUp);
            }
        };
        Command moveDown = new Command() {
            public void execute() {
                vc.setVelocityY(+1);
                vc.setVelocityX(0);
                 setImage(walkingDown);
            }
        };
        Command moveLeft = new Command() {
            public void execute() {
                vc.setVelocityX(-1);
                vc.setVelocityY(0);
                 setImage(walkingLeft);
            }
        };
        Command moveRight = new Command() {
            public void execute() {
                vc.setVelocityX(+1);
                vc.setVelocityY(0);
                 setImage(walkingRight);
            }
        };
        Command stopMoving = new Command() {
            public void execute() {
                vc.setVelocityX(0);
                vc.setVelocityY(0);
                 setImage(standing);
            }
        };
        Command fireArrow = new Command() {
            public void execute() {
                if(myArrow.isReady()){
                    myArrow.setTranslateX(vc.getNode().getTranslateX() + 8);
                myArrow.setTranslateY(vc.getNode().getTranslateY());
                myArrow.justFired();
                setImage(fire);
                }
                
            }
        };

        //Build the table of keyboard commands
        KeyCode up = KeyCode.UP;
        KeyCode down = KeyCode.DOWN;
        KeyCode left = KeyCode.LEFT;
        KeyCode right = KeyCode.RIGHT;
        
        KeyCode w = KeyCode.W;
        KeyCode s = KeyCode.S;
        KeyCode a = KeyCode.A;
        KeyCode d = KeyCode.D;
        
        KeyCode space = KeyCode.SPACE;

        Map<KeyCode, Command> inputControl = new HashMap<>();
        inputControl.put(up, moveUp);
        inputControl.put(down, moveDown);
        inputControl.put(left, moveLeft);
        inputControl.put(right, moveRight);
        inputControl.put(w, moveUp);
        inputControl.put(s, moveDown);
        inputControl.put(a, moveLeft);
        inputControl.put(d, moveRight);
        inputControl.put(space, fireArrow);

        //Tell the scene to watch for key presses and check the table
        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent evt) {
                Command command = inputControl.get(evt.getCode());

                if (command != null) {
                    command.execute();
                }
                //command will be null in the case that the pressed
                // key is not in the table. In that case, do nothing.
            }
        });
        
       
        scene.setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent evt) {
                stopMoving.execute();
                //command will be null in the case that the pressed
                // key is not in the table. In that case, do nothing.
            }
        });

    }
    
    public VelocityComponent getVelocityComponent() {
        return vc;
    }
    

    public void update() {
        if(this.getTranslateX() < 42){ //keeps link inside the main area
            this.setTranslateX(42);
        }
        else if(this.getTranslateX() > 199){
            this.setTranslateX(199);
        }
        if(this.getTranslateY() < 137){
            this.setTranslateY(137);
        }
        else if(this.getTranslateY() > 175){
            this.setTranslateY(175);
        }
        vc.update(0.016);
    }

}
