/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videogameexam1;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.Node;

/**
 *
 * @author Alfster
 */
public class Arrow extends Sprite {

    //private final Node node;
    //private double dx, dy;
    private VelocityComponent vc;
    private boolean ready;
    private int amount;

    public Arrow(String difficulty) {
        super(new ImageView(new Image("resources/Arrow.png")));
        vc = new VelocityComponent(this, 0, -3);
        this.setTranslateX(-100);//Make it off screen unless fired
        this.setTranslateY(-100); 
        ready = true;
        if(difficulty.equals("Easy")){
            amount = 7;
        }
        else if(difficulty.equals("Medium")){
            amount = 5;
        }
        else if(difficulty.equals("Hard")){
            amount = 3;
        }
    }
    
    public void justFired(){
        ready = false;
        amount--;
    }
    
    public boolean isReady(){
        return ready;
    }

    public VelocityComponent getVelocityComponent() {
        return vc;
    }

    public void update() {
        //256 is the width of the screen
        if(this.getTranslateY() < 0){
            ready = true;
            if(amount == 0){//makes it negative so if their last arrow missed 
                amount--;
            }
        }
        vc.update(0.016);
    }
    
    public void setAmount(int i){
        amount = i;
    }

    public int getAmount() {
        return amount;
    }
   
}
