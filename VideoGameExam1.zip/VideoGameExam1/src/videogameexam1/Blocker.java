/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videogameexam1;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author Alfster
 */
public class Blocker extends Sprite {

    //private final Node node;
    //private double dx, dy;
    private VelocityComponent vc;

    public Blocker(int i, double speed) {
        super(new ImageView(new Image("resources/block.png")));
        vc = new VelocityComponent(this, .5 + speed, 0);
        this.setTranslateX(i * 40);
        this.setTranslateY(80); //80 is the exact front at the green line

    }

    public VelocityComponent getVelocityComponent() {
        return vc;
    }

    public void update() {
        //256 is the width of the screen
        if(this.getTranslateX() > 256){
            this.setTranslateX(0);
        }
        vc.update(0.016);
    }
}
