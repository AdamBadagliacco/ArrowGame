/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videogameexam1;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author Alfster
 */
public class Target extends Sprite {

    //private final Node node;
    //private double dx, dy;
    private VelocityComponent vc;

    public Target(int i, double speed) {
        super(new ImageView(new Image("resources/target.png")));
        vc = new VelocityComponent(this, -speed, 0);
        this.setTranslateX(i * 50);
        this.setTranslateY(62); 

    }

    public VelocityComponent getVelocityComponent() {
        return vc;
    }

    public void update() {
        //256 is the width of the screen
        if(this.getTranslateX() < 0){
            this.setTranslateX(256);
        }
        vc.update(0.016);
    }
}
