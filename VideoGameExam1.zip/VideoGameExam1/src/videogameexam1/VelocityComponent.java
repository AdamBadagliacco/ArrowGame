/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videogameexam1;
import javafx.scene.Node;

public class VelocityComponent
{
    private double dx, dy;
    private final Node node;
    
    public VelocityComponent(Node node)
    {
        dx = 0;
        dy = 0;
        this.node = node;
    }

    public VelocityComponent(Node node, double dx, double dy)
    {
        this.dx = dx;
        this.dy = dy;
        this.node = node;
    }

    public void setVelocity(double dx, double dy)
    {
        this.dx = dx;
        this.dy = dy;
    }
    
    public Node getNode(){
        return node;
    }

    public double getVelocityX()
    {
        return dx;
    }

    public void setVelocityX(double dx)
    {
        this.dx = dx;
    }

    public double getVelocityY()
    {
        return dy;
    }

    public void setVelocityY(double dy)
    {
        this.dy = dy;
    }
    
    public void update(double dt)
    {
        double ticks = 60*dt;
        //add the velocity to the location
        this.node.setTranslateX(this.node.getTranslateX()+dx*ticks);
        this.node.setTranslateY(this.node.getTranslateY()+dy*ticks);
    }
    
}
